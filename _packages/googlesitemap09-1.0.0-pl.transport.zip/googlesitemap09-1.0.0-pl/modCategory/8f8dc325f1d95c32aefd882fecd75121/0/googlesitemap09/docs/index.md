# GoogleSitemap0.9

XML Sitemap Extra with Template Variables to override dynamic processing

After Install:
1. update the "templates" you want to list in the installed template. The default is "1".
2. update the Template => TV Access for the override options
