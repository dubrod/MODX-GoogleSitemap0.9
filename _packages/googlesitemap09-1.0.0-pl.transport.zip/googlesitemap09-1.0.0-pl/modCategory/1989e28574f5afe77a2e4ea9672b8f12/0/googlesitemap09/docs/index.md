# GoogleSitemap0.9

XML Sitemap Extra with Template Variables to override dynamic processing
