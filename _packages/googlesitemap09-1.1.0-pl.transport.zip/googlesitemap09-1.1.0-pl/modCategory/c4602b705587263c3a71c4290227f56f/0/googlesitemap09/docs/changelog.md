# GoogleSitemap0.9 1.0.0
- Basic Override Options

# GoogleSitemap0.9 1.1.0
- Added Image Node per resource
